package kz.sdk.shina.utils

interface BottomNavigationViewListener {
    fun showBottomNavigationView(show: Boolean)
}