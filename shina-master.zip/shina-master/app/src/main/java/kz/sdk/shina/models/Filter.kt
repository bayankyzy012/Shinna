package kz.sdk.shina.models

data class Filter(
    var id:Int,
    var title:String,
)
